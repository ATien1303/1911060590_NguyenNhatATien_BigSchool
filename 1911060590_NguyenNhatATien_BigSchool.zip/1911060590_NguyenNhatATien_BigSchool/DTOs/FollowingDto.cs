﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _1911060590_NguyenNhatATien_BigSchool.DTOs
{
    public class FollowingDto
    {
        public string FolloweeId { get; set; }
        public int CourseId { get; set; }
    }
}